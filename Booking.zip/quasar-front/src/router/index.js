import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'
import Calendar from '../views/Calendar.vue'
import Resources from '../views/Resources.vue'

const routes = [
  { path: '/', name: 'Dashboard', component: Dashboard },
  { path: '/calendar', name: 'Calendar', component: Calendar },
  { path: '/resources', name: 'Resources', component: Resources }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router