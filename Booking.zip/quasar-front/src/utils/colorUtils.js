// Мини‑помощник для окраски разных типов ресурсов
export function getResourceColor(type) {
  switch (type) {
    case 'зал': return '#4caf50';
    case 'оборудование': return '#2196f3';
    default: return '#9e9e9e';
  }
}