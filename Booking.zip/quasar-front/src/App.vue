<template>
  <div id="app">
    <header class="app-header">
      <div class="container">
        <div class="header-content">
          <div class="logo">
            <router-link to="/" class="logo-link">
              <span class="logo-icon">📅</span>
              <span class="logo-text">ResourceBooker</span>
            </router-link>
          </div>
          
          <nav class="main-nav">
            <router-link to="/" class="nav-link" active-class="active" exact>
              <span class="nav-icon">🏠</span>
              <span class="nav-text">Главная</span>
            </router-link>
            <router-link to="/calendar" class="nav-link" active-class="active">
              <span class="nav-icon">📅</span>
              <span class="nav-text">Календарь</span>
            </router-link>
            <router-link to="/resources" class="nav-link" active-class="active">
              <span class="nav-icon">🛠️</span>
              <span class="nav-text">Ресурсы</span>
            </router-link>
            <router-link to="/bookings" class="nav-link" active-class="active">
              <span class="nav-icon">📋</span>
              <span class="nav-text">Мои брони</span>
            </router-link>
          </nav>
          
          <div class="header-right">
            <NotificationBell />
            <div class="user-menu">
              <button class="user-btn">
                <span class="user-avatar">👤</span>
                <span class="user-name">Пользователь</span>
                <span class="dropdown-arrow">▼</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>

    <main class="app-main">
      <div class="container">
        <router-view />
      </div>
    </main>

    <footer class="app-footer">
      <div class="container">
        <div class="footer-content">
          <div class="footer-info">
            <span class="footer-logo">📅 ResourceBooker</span>
            <p class="footer-description">
              Система бронирования ресурсов 2024
            </p>
          </div>
          <div class="footer-links">
            <a href="#" class="footer-link">Помощь</a>
            <a href="#" class="footer-link">Контакты</a>
            <a href="#" class="footer-link">Политика</a>
          </div>
        </div>
      </div>
    </footer>
  </div>
</template>

<script>
import NotificationBell from './components/NotificationBell.vue';

export default {
  name: 'App',
  components: {
    NotificationBell
  }
};
</script>

<style>
/* Сброс стилей и базовые настройки */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  line-height: 1.6;
  color: #333;
  background-color: #f8f9fa;
}

#app {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

/* Шапка */
.app-header {
  background: linear-gradient(135deg, #2c3e50 0%, #3498db 100%);
  color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  position: sticky;
  top: 0;
  z-index: 1000;
}

.header-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 70px;
}

.logo-link {
  display: flex;
  align-items: center;
  text-decoration: none;
  color: white;
  font-size: 1.5rem;
  font-weight: bold;
  transition: opacity 0.2s;
}

.logo-link:hover {
  opacity: 0.9;
}

.logo-icon {
  font-size: 2rem;
  margin-right: 10px;
}

.logo-text {
  font-family: 'Arial Rounded MT Bold', 'Arial', sans-serif;
}

/* Основная навигация */
.main-nav {
  display: flex;
  gap: 5px;
  flex: 1;
  justify-content: center;
  margin: 0 30px;
}

.nav-link {
  display: flex;
  align-items: center;
  text-decoration: none;
  color: rgba(255, 255, 255, 0.85);
  padding: 10px 20px;
  border-radius: 8px;
  transition: all 0.3s ease;
  font-weight: 500;
}

.nav-link:hover {
  background: rgba(255, 255, 255, 0.1);
  color: white;
  transform: translateY(-2px);
}

.nav-link.active {
  background: rgba(255, 255, 255, 0.15);
  color: white;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.nav-icon {
  font-size: 1.2rem;
  margin-right: 8px;
}

.nav-text {
  font-size: 0.95rem;
}

/* Правая часть шапки */
.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
}

.user-btn {
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.1);
  border: none;
  color: white;
  padding: 8px 15px;
  border-radius: 20px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 0.9rem;
}

.user-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: scale(1.05);
}

.user-avatar {
  font-size: 1.2rem;
  margin-right: 8px;
}

.user-name {
  margin-right: 8px;
}

.dropdown-arrow {
  font-size: 0.7rem;
  opacity: 0.8;
}

/* Основное содержимое */
.app-main {
  flex: 1;
  padding: 30px 0;
  background-color: #f8f9fa;
}

/* Подвал */
.app-footer {
  background: #2c3e50;
  color: rgba(255, 255, 255, 0.8);
  padding: 25px 0;
  margin-top: auto;
}

.footer-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.footer-logo {
  font-size: 1.3rem;
  font-weight: bold;
  color: white;
  margin-bottom: 10px;
  display: block;
}

.footer-description {
  font-size: 0.9rem;
  opacity: 0.7;
}

.footer-links {
  display: flex;
  gap: 25px;
}

.footer-link {
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  font-size: 0.9rem;
  transition: color 0.3s;
  position: relative;
}

.footer-link:hover {
  color: white;
}

.footer-link::after {
  content: '';
  position: absolute;
  width: 0;
  height: 2px;
  bottom: -5px;
  left: 0;
  background-color: #3498db;
  transition: width 0.3s;
}

.footer-link:hover::after {
  width: 100%;
}

/* Адаптивность */
@media (max-width: 1024px) {
  .container {
    padding: 0 15px;
  }
  
  .main-nav {
    margin: 0 15px;
  }
  
  .nav-text {
    display: none;
  }
  
  .nav-icon {
    margin-right: 0;
    font-size: 1.4rem;
  }
  
  .nav-link {
    padding: 10px 15px;
  }
}

@media (max-width: 768px) {
  .header-content {
    flex-wrap: wrap;
    height: auto;
    padding: 15px 0;
  }
  
  .logo {
    width: 100%;
    text-align: center;
    margin-bottom: 15px;
  }
  
  .main-nav {
    order: 3;
    width: 100%;
    margin: 15px 0 0 0;
  }
  
  .header-right {
    order: 2;
  }
  
  .footer-content {
    flex-direction: column;
    text-align: center;
    gap: 20px;
  }
  
  .footer-links {
    justify-content: center;
  }
}

@media (max-width: 480px) {
  .nav-link {
    padding: 8px 12px;
  }
  
  .nav-icon {
    font-size: 1.2rem;
  }
  
  .user-name {
    display: none;
  }
  
  .dropdown-arrow {
    margin-left: 5px;
  }
}

/* Анимации */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.fade-in {
  animation: fadeIn 0.3s ease-out;
}

/* Кастомный скроллбар */
::-webkit-scrollbar {
  width: 8px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb {
  background: #c1c1c1;
  border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
  background: #a8a8a8;
}

/* Утилитарные классы */
.text-center {
  text-align: center;
}

.mt-20 {
  margin-top: 20px;
}

.mb-20 {
  margin-bottom: 20px;
}

.p-20 {
  padding: 20px;
}

.card {
  background: white;
  border-radius: 12px;
  padding: 25px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s, box-shadow 0.3s;
}

.card:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
}

.btn {
  display: inline-block;
  padding: 12px 24px;
  background: #3498db;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 1rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s;
  text-decoration: none;
  text-align: center;
}

.btn:hover {
  background: #2980b9;
  transform: translateY(-1px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.btn:active {
  transform: translateY(0);
}

.btn-secondary {
  background: #95a5a6;
}

.btn-secondary:hover {
  background: #7f8c8d;
}

.btn-success {
  background: #2ecc71;
}

.btn-success:hover {
  background: #27ae60;
}

.btn-danger {
  background: #e74c3c;
}

.btn-danger:hover {
  background: #c0392b;
}
</style>