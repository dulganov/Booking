import { useResourcesStore } from '../store/resources';

export async function fetchResources() {
  const store = useResourcesStore();
  return Promise.resolve(store.resources);
}

export async function addResource(data) {
  const store = useResourcesStore();
  store.addResource(data);
  return Promise.resolve(true);
}