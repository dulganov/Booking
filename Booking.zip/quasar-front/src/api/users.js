import { useUserStore } from '../store/user';

export async function loginUser(name) {
  const store = useUserStore();
  store.login(name);
  return Promise.resolve(store.name);
}

export async function logoutUser() {
  const store = useUserStore();
  store.logout();
  return Promise.resolve(true);
}