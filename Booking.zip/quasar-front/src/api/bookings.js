// Заглушки для демонстрации работы без реального backend
import { useBookingsStore } from '../store/bookings';

export async function fetchBookings() {
  const store = useBookingsStore();
  return Promise.resolve(store.bookings);
}

export async function createBooking(data) {
  const store = useBookingsStore();
  store.createBooking(data);
  return Promise.resolve(true);
}