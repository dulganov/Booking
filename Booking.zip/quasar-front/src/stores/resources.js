import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useResourcesStore = defineStore('resources', () => {
  const resources = ref([
    { 
      id: 1, 
      name: 'Конференц-зал A', 
      type: 'meeting_room', 
      description: 'Зал на 20 человек с проектором',
      capacity: 20,
      manager: 'Иван Иванов',
      location: 'Этаж 3, комната 301',
      image: 'https://via.placeholder.com/300x200?text=Conference+Room',
      availability: { 
        weekdays: ['09:00-18:00'], 
        weekends: ['10:00-16:00'] 
      }
    },
    { 
      id: 2, 
      name: 'Фотограф', 
      type: 'service', 
      description: 'Профессиональный фотограф для мероприятий',
      capacity: 1,
      manager: 'Анна Петрова',
      location: 'Офис фотографа',
      image: 'https://via.placeholder.com/300x200?text=Photographer',
      availability: { 
        weekdays: ['10:00-20:00'], 
        weekends: ['11:00-19:00'] 
      }
    },
    { 
      id: 3, 
      name: 'Проектор', 
      type: 'equipment', 
      description: 'HD проектор с экраном',
      capacity: null,
      manager: 'IT отдел',
      location: 'Склад техники',
      image: 'https://via.placeholder.com/300x200?text=Projector',
      availability: { 
        weekdays: ['09:00-18:00'], 
        weekends: [] 
      }
    }
  ])
  
  const loading = ref(false)
  
  const resourceTypes = computed(() => {
    const types = {}
    resources.value.forEach(resource => {
      if (!types[resource.type]) {
        types[resource.type] = {
          meeting_room: 'Переговорная',
          service: 'Услуга',
          equipment: 'Оборудование'
        }[resource.type] || resource.type
      }
    })
    return types
  })
  
  const addResource = (resourceData) => {
    const newResource = {
      id: Date.now(),
      ...resourceData,
      createdAt: new Date().toISOString()
    }
    resources.value.push(newResource)
    return newResource
  }
  
  const updateResource = (id, updates) => {
    const index = resources.value.findIndex(r => r.id === id)
    if (index !== -1) {
      resources.value[index] = { ...resources.value[index], ...updates }
    }
  }
  
  const deleteResource = (id) => {
    resources.value = resources.value.filter(r => r.id !== id)
  }
  
  const getResourceById = (id) => {
    return resources.value.find(r => r.id === id)
  }
  
  const fetchResources = async () => {
    loading.value = true
    try {
      // Имитация API запроса
      await new Promise(resolve => setTimeout(resolve, 500))
      return resources.value
    } finally {
      loading.value = false
    }
  }
  
  return {
    resources,
    loading,
    resourceTypes,
    addResource,
    updateResource,
    deleteResource,
    getResourceById,
    fetchResources
  }
})