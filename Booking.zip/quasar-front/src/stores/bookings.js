import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { useAuthStore } from './auth'

export const useBookingsStore = defineStore('bookings', () => {
  const bookings = ref([
    {
      id: 1,
      resourceId: 1,
      userId: 1,
      title: 'Совещание отдела',
      date: '2024-01-15',
      timeStart: '10:00',
      timeEnd: '12:00',
      status: 'confirmed',
      participants: ['user1@example.com', 'user2@example.com'],
      description: 'Еженедельное совещание отдела разработки',
      createdAt: '2024-01-10T09:00:00Z'
    },
    {
      id: 2,
      resourceId: 2,
      userId: 2,
      title: 'Фотосессия для проекта',
      date: '2024-01-16',
      timeStart: '14:00',
      timeEnd: '16:00',
      status: 'pending',
      participants: ['user3@example.com'],
      description: 'Фотосессия для нового рекламного проекта',
      createdAt: '2024-01-11T11:00:00Z'
    }
  ])
  
  const loading = ref(false)
  const authStore = useAuthStore()
  
  // Бронирования текущего пользователя
  const myBookings = computed(() => {
    if (!authStore.user) return []
    return bookings.value.filter(b => b.userId === authStore.user.id)
  })
  
  // Проверка доступности времени
  const isTimeSlotAvailable = (resourceId, date, timeStart, timeEnd, excludeBookingId = null) => {
    const conflictingBookings = bookings.value.filter(booking => {
      if (booking.resourceId !== resourceId || booking.date !== date) return false
      if (excludeBookingId && booking.id === excludeBookingId) return false
      if (booking.status === 'cancelled') return false
      
      const start1 = timeToMinutes(timeStart)
      const end1 = timeToMinutes(timeEnd)
      const start2 = timeToMinutes(booking.timeStart)
      const end2 = timeToMinutes(booking.timeEnd)
      
      return !(end1 <= start2 || start1 >= end2)
    })
    
    return conflictingBookings.length === 0
  }
  
  const timeToMinutes = (time) => {
    const [hours, minutes] = time.split(':').map(Number)
    return hours * 60 + minutes
  }
  
  const createBooking = async (bookingData) => {
    // Проверяем доступность
    if (!isTimeSlotAvailable(
      bookingData.resourceId,
      bookingData.date,
      bookingData.timeStart,
      bookingData.timeEnd
    )) {
      throw new Error('Время уже занято')
    }
    
    const newBooking = {
      id: Date.now(),
      userId: authStore.user.id,
      status: 'pending',
      createdAt: new Date().toISOString(),
      ...bookingData
    }
    
    bookings.value.push(newBooking)
    return newBooking
  }
  
  const updateBooking = (id, updates) => {
    const index = bookings.value.findIndex(b => b.id === id)
    if (index !== -1) {
      bookings.value[index] = { ...bookings.value[index], ...updates }
    }
  }
  
  const cancelBooking = (id) => {
    const booking = bookings.value.find(b => b.id === id)
    if (booking && booking.userId === authStore.user.id) {
      booking.status = 'cancelled'
    }
  }
  
  const getBookingsByResource = (resourceId) => {
    return bookings.value.filter(b => 
      b.resourceId === resourceId && 
      b.status !== 'cancelled'
    )
  }
  
  const getBookingsByDate = (date) => {
    return bookings.value.filter(b => b.date === date)
  }
  
  const fetchBookings = async () => {
    loading.value = true
    try {
      // Имитация API запроса
      await new Promise(resolve => setTimeout(resolve, 500))
      return bookings.value
    } finally {
      loading.value = false
    }
  }
  
  return {
    bookings,
    loading,
    myBookings,
    isTimeSlotAvailable,
    createBooking,
    updateBooking,
    cancelBooking,
    getBookingsByResource,
    getBookingsByDate,
    fetchBookings
  }
})