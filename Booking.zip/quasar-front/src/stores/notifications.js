import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { useAuthStore } from './auth'

export const useNotificationsStore = defineStore('notifications', () => {
  const notifications = ref([
    {
      id: 1,
      userId: 1,
      type: 'booking_created',
      title: 'Новое бронирование',
      message: 'Ваше бронирование "Совещание отдела" подтверждено',
      read: false,
      createdAt: '2024-01-12T10:00:00Z',
      data: { bookingId: 1 }
    },
    {
      id: 2,
      userId: 1,
      type: 'booking_reminder',
      title: 'Напоминание',
      message: 'Завтра в 10:00 у вас запланировано совещание',
      read: false,
      createdAt: '2024-01-14T09:00:00Z',
      data: { bookingId: 1 }
    }
  ])
  
  const authStore = useAuthStore()
  
  const unreadCount = computed(() => {
    if (!authStore.user) return 0
    return notifications.value.filter(n => 
      n.userId === authStore.user.id && !n.read
    ).length
  })
  
  const userNotifications = computed(() => {
    if (!authStore.user) return []
    return notifications.value
      .filter(n => n.userId === authStore.user.id)
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
  })
  
  const markAsRead = (id) => {
    const notification = notifications.value.find(n => n.id === id)
    if (notification) {
      notification.read = true
    }
  }
  
  const markAllAsRead = () => {
    notifications.value.forEach(n => {
      if (n.userId === authStore.user.id) {
        n.read = true
      }
    })
  }
  
  const addNotification = (notificationData) => {
    const newNotification = {
      id: Date.now(),
      read: false,
      createdAt: new Date().toISOString(),
      ...notificationData
    }
    notifications.value.push(newNotification)
  }
  
  const removeNotification = (id) => {
    notifications.value = notifications.value.filter(n => n.id !== id)
  }
  
  return {
    notifications,
    unreadCount,
    userNotifications,
    markAsRead,
    markAllAsRead,
    addNotification,
    removeNotification
  }
})