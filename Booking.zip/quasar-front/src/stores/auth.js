import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useAuthStore = defineStore('auth', () => {
  const user = ref(null)
  const token = ref(localStorage.getItem('token'))
  
  const isAuthenticated = computed(() => !!token.value && !!user.value)
  
  const login = async (credentials) => {
    try {
      // Имитация API запроса
      const response = await new Promise(resolve => 
        setTimeout(() => resolve({
          data: {
            user: { id: 1, name: credentials.email.split('@')[0], email: credentials.email, role: 'user' },
            token: 'mock-jwt-token'
          }
        }), 500)
      )
      
      user.value = response.data.user
      token.value = response.data.token
      localStorage.setItem('token', response.data.token)
      localStorage.setItem('user', JSON.stringify(response.data.user))
      
      return { success: true }
    } catch (error) {
      return { success: false, error: error.message }
    }
  }
  
  const logout = () => {
    user.value = null
    token.value = null
    localStorage.removeItem('token')
    localStorage.removeItem('user')
  }
  
  const checkAuth = () => {
    const storedToken = localStorage.getItem('token')
    const storedUser = localStorage.getItem('user')
    
    if (storedToken && storedUser) {
      token.value = storedToken
      user.value = JSON.parse(storedUser)
    }
  }
  
  return {
    user,
    token,
    isAuthenticated,
    login,
    logout,
    checkAuth
  }
})