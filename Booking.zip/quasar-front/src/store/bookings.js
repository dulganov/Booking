import { defineStore } from 'pinia';

export const useBookingsStore = defineStore('bookings', {
  state: () => ({
    bookings: [
      { id: 1, resourceId: 1, date: '2024-05-28', timeStart: '10:00', timeEnd: '11:00', user: 'Алексей' }
    ]
  }),
  actions: {
    createBooking(b) {
      const conflict = this.bookings.some(existing =>
        existing.resourceId === b.resourceId &&
        existing.date === b.date &&
        !(b.timeEnd <= existing.timeStart || b.timeStart >= existing.timeEnd)
      );
      if (conflict) throw new Error('Ресурс уже забронирован на это время!');
      this.bookings.push({ id: Date.now(), ...b });
    },
    getBookingsByUser(user) {
      return this.bookings.filter(b => b.user === user);
    }
  }
});