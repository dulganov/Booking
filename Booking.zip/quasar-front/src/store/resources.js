import { defineStore } from 'pinia';

export const useResourcesStore = defineStore('resources', {
  state: () => ({
    resources: [
      { id: 1, name: 'Конференц-зал', type: 'зал', manager: 'Ирина' },
      { id: 2, name: 'Фотоаппарат Canon', type: 'оборудование', manager: 'Павел' },
    ]
  }),
  actions: {
    addResource(data) {
      data.id = Date.now();
      this.resources.push(data);
    },
    removeResource(id) {
      this.resources = this.resources.filter(r => r.id !== id);
    }
  }
});