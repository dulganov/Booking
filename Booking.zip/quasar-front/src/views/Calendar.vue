<template>
  <div class="calendar-page">
    <h1>Календарь бронирований</h1>
    <CalendarView />
  </div>
</template>

<script>
import CalendarView from '../components/CalendarView.vue'

export default {
  name: 'CalendarPage', // Исправлено
  components: {
    CalendarView
  }
}
</script>