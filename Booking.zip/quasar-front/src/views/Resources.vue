<template>
  <div class="resources-page">
    <h1>Управление ресурсами</h1>
    <ResourceList />
  </div>
</template>

<script>
import ResourceList from '../components/ResourceList.vue'

export default {
  name: 'ResourcesPage', // Исправлено
  components: {
    ResourceList
  }
}
</script>