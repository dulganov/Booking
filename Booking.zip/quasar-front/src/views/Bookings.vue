<template>
  <div class="bookings-page">
    <h1>Мои бронирования</h1>
    
    <div v-if="bookings.length === 0" class="empty-state">
      <p>У вас пока нет активных бронирований</p>
      <router-link to="/calendar" class="btn-primary">
        Забронировать ресурс
      </router-link>
    </div>
    
    <div v-else class="bookings-list">
      <div v-for="booking in bookings" :key="booking.id" class="booking-card">
        <div class="booking-header">
          <h3>{{ booking.resourceName }}</h3>
          <span class="booking-status" :class="booking.status">
            {{ getStatusText(booking.status) }}
          </span>
        </div>
        
        <div class="booking-details">
          <p><strong>Дата и время:</strong> {{ formatDateTime(booking.startTime) }}</p>
          <p><strong>Продолжительность:</strong> {{ booking.duration }} час(а)</p>
          <p><strong>Цель:</strong> {{ booking.purpose }}</p>
          <p v-if="booking.participants.length > 0">
            <strong>Участники:</strong> {{ booking.participants.join(', ') }}
          </p>
        </div>
        
        <div class="booking-actions">
          <button 
            v-if="booking.status === 'pending' || booking.status === 'confirmed'"
            @click="cancelBooking(booking.id)"
            class="btn-cancel"
          >
            Отменить бронирование
          </button>
          <button 
            @click="editBooking(booking)"
            class="btn-edit"
          >
            Изменить
          </button>
        </div>
      </div>
    </div>
    
    <div v-if="showEditModal" class="edit-modal">
      <!-- Модальное окно редактирования -->
    </div>
  </div>
</template>

<script>
export default {
  name: 'MyBookingsPage', // ИСПРАВЛЕНО: многословное имя
  data() {
    return {
      bookings: [
        {
          id: 1,
          resourceName: 'Конференц-зал A',
          startTime: new Date('2024-01-15T10:00:00'),
          duration: 2,
          purpose: 'Совещание по проекту',
          participants: ['ivan@company.com', 'petr@company.com'],
          status: 'confirmed' // pending, confirmed, cancelled, completed
        },
        {
          id: 2,
          resourceName: 'Фотостудия',
          startTime: new Date('2024-01-16T14:00:00'),
          duration: 3,
          purpose: 'Фотосессия для сайта',
          participants: ['design@company.com'],
          status: 'pending'
        }
      ],
      showEditModal: false,
      editingBooking: null
    };
  },
  methods: {
    formatDateTime(date) {
      if (!date) return '';
      const d = new Date(date);
      return d.toLocaleDateString('ru-RU') + ' ' + d.toLocaleTimeString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit'
      });
    },
    getStatusText(status) {
      const statusMap = {
        'pending': 'Ожидает подтверждения',
        'confirmed': 'Подтверждено',
        'cancelled': 'Отменено',
        'completed': 'Завершено'
      };
      return statusMap[status] || status;
    },
    cancelBooking(id) {
      if (confirm('Вы уверены, что хотите отменить бронирование?')) {
        const index = this.bookings.findIndex(b => b.id === id);
        if (index !== -1) {
          this.bookings[index].status = 'cancelled';
        }
      }
    },
    editBooking(booking) {
      this.editingBooking = { ...booking };
      this.showEditModal = true;
    },
    loadBookings() {
      // Загрузка бронирований с API
      // this.$api.get('/bookings/my').then(response => {
      //   this.bookings = response.data;
      // });
    }
  },
  mounted() {
    this.loadBookings();
  }
};
</script>

<style scoped>
.bookings-page {
  padding: 20px;
}

.empty-state {
  text-align: center;
  padding: 40px;
  background: #f5f5f5;
  border-radius: 8px;
  margin-top: 20px;
}

.btn-primary {
  display: inline-block;
  background: #4CAF50;
  color: white;
  padding: 10px 20px;
  text-decoration: none;
  border-radius: 4px;
  margin-top: 10px;
}

.bookings-list {
  display: grid;
  gap: 20px;
  margin-top: 20px;
}

.booking-card {
  border: 1px solid #ddd;
  border-radius: 8px;
  padding: 20px;
  background: white;
}

.booking-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.booking-status {
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: bold;
}

.booking-status.pending {
  background: #fff3cd;
  color: #856404;
}

.booking-status.confirmed {
  background: #d4edda;
  color: #155724;
}

.booking-status.cancelled {
  background: #f8d7da;
  color: #721c24;
}

.booking-status.completed {
  background: #d1ecf1;
  color: #0c5460;
}

.booking-details p {
  margin: 5px 0;
}

.booking-actions {
  display: flex;
  gap: 10px;
  margin-top: 15px;
}

.btn-cancel, .btn-edit {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.btn-cancel {
  background: #f44336;
  color: white;
}

.btn-edit {
  background: #2196F3;
  color: white;
}
</style>