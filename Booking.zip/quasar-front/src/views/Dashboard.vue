<template>
  <div class="dashboard">
    <h1>Панель управления</h1>
    <p>Добро пожаловать в систему бронирования ресурсов</p>
  </div>
</template>

<script>
export default {
  name: 'DashboardPage' // Исправлено
}
</script>