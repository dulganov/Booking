<template>
  <div class="booking-modal">
    <div class="modal-content">
      <h3>Бронирование {{ resource.name }}</h3>
      
      <form @submit.prevent="submitBooking">
        <div>
          <label>Дата и время:</label>
          <input 
            type="datetime-local" 
            v-model="localStartTime"
            required
          />
        </div>
        
        <div>
          <label>Продолжительность (часы):</label>
          <input 
            type="number" 
            v-model="duration" 
            min="1" 
            max="8"
            required
          />
        </div>
        
        <div>
          <label>Цель бронирования:</label>
          <textarea v-model="purpose" required></textarea>
        </div>
        
        <div>
          <label>Участники:</label>
          <input 
            type="email" 
            v-model="participantEmail"
            placeholder="Добавить участника"
            @keyup.enter="addParticipant"
          />
          <ul>
            <li v-for="(p, index) in participants" :key="index">
              {{ p }}
              <button type="button" @click="removeParticipant(index)">×</button>
            </li>
          </ul>
        </div>
        
        <button type="submit">Забронировать</button>
        <button type="button" @click="$emit('cancel')">Отмена</button>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: 'BookingFormComponent', // Многословное имя
  props: {
    resource: {
      type: Object,
      required: true
    },
    startTime: {
      type: Date,
      required: true
    }
  },
  data() {
    return {
      duration: 1,
      purpose: '',
      participants: [],
      participantEmail: '',
      localStartTime: this.startTime.toISOString().slice(0, 16)
    };
  },
  methods: {
    addParticipant() {
      if (this.participantEmail && this.participants.length < 10) {
        this.participants.push(this.participantEmail);
        this.participantEmail = '';
      }
    },
    removeParticipant(index) {
      this.participants.splice(index, 1);
    },
    submitBooking() {
      const bookingData = {
        resourceId: this.resource.id,
        resourceName: this.resource.name,
        startTime: new Date(this.localStartTime),
        duration: this.duration,
        purpose: this.purpose,
        participants: this.participants,
        userId: this.$store?.state?.user?.id || null
      };
      
      this.$emit('book', bookingData);
    }
  },
  watch: {
    startTime(newVal) {
      this.localStartTime = newVal.toISOString().slice(0, 16);
    }
  }
};
</script>

<style scoped>
.booking-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
}

.modal-content {
  background: white;
  padding: 20px;
  border-radius: 8px;
  min-width: 400px;
  max-width: 500px;
}

input, textarea, select {
  width: 100%;
  margin: 8px 0;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  margin: 5px;
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button[type="submit"] {
  background-color: #4CAF50;
  color: white;
}

button[type="button"] {
  background-color: #f44336;
  color: white;
}
</style>