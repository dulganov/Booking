<template>
  <div class="resource-list-container">
    <div class="resource-header">
      <h1 class="page-title">📦 Управление ресурсами</h1>
      <p class="page-subtitle">Добавляйте, редактируйте и удаляйте доступные ресурсы для бронирования</p>
    </div>

    <!-- Кнопка добавления -->
    <div class="add-resource-btn-wrapper">
      <button 
        @click="showAddForm = true" 
        class="add-resource-btn"
        :disabled="showAddForm"
      >
        <span class="btn-icon">+</span>
        <span class="btn-text">Добавить ресурс</span>
        <span class="btn-hint">Нажмите для создания нового ресурса</span>
      </button>
    </div>

    <!-- Форма добавления/редактирования -->
    <div v-if="showAddForm" class="resource-form-modal">
      <div class="modal-overlay" @click="cancelForm"></div>
      <div class="modal-content">
        <div class="modal-header">
          <h3>
            <span class="modal-icon">{{ editingResource ? '✏️' : '➕' }}</span>
            {{ editingResource ? 'Редактировать ресурс' : 'Добавить новый ресурс' }}
          </h3>
          <button @click="cancelForm" class="close-btn">×</button>
        </div>

        <div class="form-body">
          <div class="form-group">
            <label for="resourceName">
              <span class="label-icon">🏷️</span>
              Название ресурса
            </label>
            <input 
              id="resourceName"
              v-model="formData.name" 
              placeholder="Например: Конференц-зал 'Солнце'"
              type="text"
              class="form-input"
              :class="{ 'error': !formData.name && formSubmitted }"
            >
            <div v-if="!formData.name && formSubmitted" class="error-message">
              Пожалуйста, укажите название ресурса
            </div>
          </div>

          <div class="form-group">
            <label for="resourceType">
              <span class="label-icon">📁</span>
              Тип ресурса
            </label>
            <div class="type-selector">
              <label 
                v-for="type in resourceTypes" 
                :key="type.value"
                class="type-option"
                :class="{ 'selected': formData.type === type.value }"
              >
                <input 
                  type="radio" 
                  :value="type.value" 
                  v-model="formData.type"
                  hidden
                >
                <span class="type-icon">{{ type.icon }}</span>
                <span class="type-label">{{ type.label }}</span>
              </label>
            </div>
          </div>

          <div class="form-group">
            <label for="resourceResponsible">
              <span class="label-icon">👤</span>
              Ответственный
            </label>
            <input 
              id="resourceResponsible"
              v-model="formData.responsible" 
              placeholder="ФИО ответственного лица"
              type="text"
              class="form-input"
            >
            <div class="input-hint">
              Лицо, ответственное за техническое состояние ресурса
            </div>
          </div>

          <div class="form-group">
            <label for="resourceDescription">
              <span class="label-icon">📝</span>
              Описание (опционально)
            </label>
            <textarea 
              id="resourceDescription"
              v-model="formData.description" 
              placeholder="Краткое описание ресурса, особенности использования..."
              rows="3"
              class="form-textarea"
            ></textarea>
          </div>

          <div class="form-actions">
            <button @click="cancelForm" class="btn btn-secondary">
              Отменить
            </button>
            <button @click="saveResource" class="btn btn-primary">
              <span v-if="saving" class="spinner"></span>
              <span v-else>{{ editingResource ? 'Сохранить изменения' : 'Создать ресурс' }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- Список ресурсов -->
    <div v-if="resources.length > 0" class="resources-grid">
      <div 
        v-for="resource in resources" 
        :key="resource.id" 
        class="resource-card"
        :class="getResourceTypeClass(resource.type)"
      >
        <div class="resource-card-header">
          <div class="resource-type-badge">
            <span class="type-icon">{{ getTypeIcon(resource.type) }}</span>
            <span class="type-text">{{ getTypeLabel(resource.type) }}</span>
          </div>
          <div class="resource-actions">
            <button 
              @click="editResource(resource)" 
              class="action-btn edit-btn"
              title="Редактировать"
            >
              <span class="action-icon">✏️</span>
              <span class="action-text">Изменить</span>
            </button>
            <button 
              @click="deleteResource(resource.id)" 
              class="action-btn delete-btn"
              title="Удалить"
            >
              <span class="action-icon">🗑️</span>
              <span class="action-text">Удалить</span>
            </button>
          </div>
        </div>

        <div class="resource-card-body">
          <h3 class="resource-name">{{ resource.name }}</h3>
          
          <div v-if="resource.description" class="resource-description">
            {{ resource.description }}
          </div>

          <div class="resource-info">
            <div class="info-item">
              <span class="info-icon">👤</span>
              <div class="info-content">
                <span class="info-label">Ответственный:</span>
                <span class="info-value">{{ resource.responsible }}</span>
              </div>
            </div>
            
            <div class="info-item">
              <span class="info-icon">🆔</span>
              <div class="info-content">
                <span class="info-label">ID ресурса:</span>
                <span class="info-value">#{{ resource.id }}</span>
              </div>
            </div>

            <div class="info-item">
              <span class="info-icon">📊</span>
              <div class="info-content">
                <span class="info-label">Статус:</span>
                <span class="status-badge available">Доступен</span>
              </div>
            </div>
          </div>
        </div>

        <div class="resource-card-footer">
          <button class="btn btn-sm btn-outline" @click="viewResourceBookings(resource)">
            📋 Просмотреть бронирования
          </button>
        </div>
      </div>
    </div>

    <!-- Пустое состояние -->
    <div v-else class="empty-state">
      <div class="empty-state-icon">📭</div>
      <h3>Ресурсы не найдены</h3>
      <p>У вас пока нет добавленных ресурсов. Начните с создания первого!</p>
      <button @click="showAddForm = true" class="btn btn-primary">
        + Создать первый ресурс
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ResourceListComponent',
  data() {
    return {
      showAddForm: false,
      editingResource: null,
      formSubmitted: false,
      saving: false,
      formData: {
        name: '',
        type: 'room',
        responsible: '',
        description: ''
      },
      resourceTypes: [
        { value: 'room', label: 'Комната', icon: '🏢' },
        { value: 'equipment', label: 'Оборудование', icon: '💻' },
        { value: 'service', label: 'Услуга', icon: '🛠️' },
        { value: 'vehicle', label: 'Транспорт', icon: '🚗' },
        { value: 'other', label: 'Другое', icon: '📦' }
      ],
      resources: [
        { 
          id: 1, 
          name: 'Конференц-зал "Солнце"', 
          type: 'room', 
          responsible: 'Иван Иванов',
          description: 'Большой конференц-зал с проектором и звуковой системой'
        },
        { 
          id: 2, 
          name: 'Проектор Epson', 
          type: 'equipment', 
          responsible: 'Петр Петров',
          description: 'HD проектор 1080p, беспроводное подключение'
        },
        { 
          id: 3, 
          name: 'Фотостудия', 
          type: 'room', 
          responsible: 'Анна Смирнова',
          description: 'Профессиональная фотостудия с освещением и фонами'
        }
      ]
    }
  },
  methods: {
    editResource(resource) {
      this.editingResource = resource
      this.formData = { ...resource }
      this.showAddForm = true
    },
    
    deleteResource(id) {
      if (confirm('Вы уверены, что хотите удалить этот ресурс?\nВсе связанные бронирования также будут удалены.')) {
        this.resources = this.resources.filter(r => r.id !== id)
        this.showNotification('Ресурс успешно удален', 'success')
      }
    },
    
    async saveResource() {
      this.formSubmitted = true
      
      if (!this.formData.name) {
        return
      }
      
      this.saving = true
      
      // Имитация задержки сети
      await new Promise(resolve => setTimeout(resolve, 500))
      
      if (this.editingResource) {
        // Обновление
        const index = this.resources.findIndex(r => r.id === this.editingResource.id)
        this.resources[index] = { 
          ...this.formData, 
          id: this.editingResource.id 
        }
        this.showNotification('Ресурс успешно обновлен', 'success')
      } else {
        // Добавление
        const newId = Math.max(...this.resources.map(r => r.id), 0) + 1
        this.resources.push({ 
          ...this.formData, 
          id: newId 
        })
        this.showNotification('Ресурс успешно создан', 'success')
      }
      
      this.saving = false
      this.cancelForm()
    },
    
    cancelForm() {
      this.showAddForm = false
      this.editingResource = null
      this.formData = { 
        name: '', 
        type: 'room', 
        responsible: '', 
        description: '' 
      }
      this.formSubmitted = false
    },
    
    getTypeIcon(type) {
      const found = this.resourceTypes.find(t => t.value === type)
      return found ? found.icon : '📦'
    },
    
    getTypeLabel(type) {
      const found = this.resourceTypes.find(t => t.value === type)
      return found ? found.label : 'Другое'
    },
    
    getResourceTypeClass(type) {
      return `type-${type}`
    },
    
    viewResourceBookings(resource) {
      this.$router.push({
        path: '/calendar',
        query: { resource: resource.id }
      })
    },
    
    showNotification(message, type = 'info') {
      // Здесь можно использовать Quasar Notify или другой notification system
      alert(`${type === 'success' ? '✅' : 'ℹ️'} ${message}`)
    }
  }
}
</script>

<style scoped>
.resource-list-container {
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}

/* Заголовок */
.resource-header {
  text-align: center;
  margin-bottom: 40px;
}

.page-title {
  font-size: 2.5rem;
  color: #2c3e50;
  margin-bottom: 10px;
  font-weight: 700;
}

.page-subtitle {
  color: #7f8c8d;
  font-size: 1.1rem;
  max-width: 600px;
  margin: 0 auto;
}

/* Кнопка добавления */
.add-resource-btn-wrapper {
  display: flex;
  justify-content: center;
  margin-bottom: 40px;
}

.add-resource-btn {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  padding: 20px 40px;
  border-radius: 15px;
  font-size: 1.2rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  width: 100%;
  max-width: 400px;
  box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
  position: relative;
  overflow: hidden;
}

.add-resource-btn:hover:not(:disabled) {
  transform: translateY(-3px);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.5);
}

.add-resource-btn:active:not(:disabled) {
  transform: translateY(-1px);
}

.add-resource-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
  transform: none;
}

.add-resource-btn::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
  transition: 0.5s;
}

.add-resource-btn:hover:not(:disabled)::before {
  left: 100%;
}

.btn-icon {
  font-size: 2.5rem;
  font-weight: 300;
}

.btn-text {
  font-size: 1.3rem;
}

.btn-hint {
  font-size: 0.9rem;
  opacity: 0.9;
  font-weight: 400;
}

/* Форма модального окна */
.resource-form-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
}

.modal-content {
  background: white;
  border-radius: 20px;
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
  position: relative;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
  from {
    opacity: 0;
    transform: translateY(-30px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 25px;
  border-bottom: 1px solid #eee;
  background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
  border-radius: 20px 20px 0 0;
}

.modal-header h3 {
  margin: 0;
  color: #2c3e50;
  font-size: 1.4rem;
  display: flex;
  align-items: center;
  gap: 10px;
}

.modal-icon {
  font-size: 1.6rem;
}

.close-btn {
  background: none;
  border: none;
  font-size: 2rem;
  color: #7f8c8d;
  cursor: pointer;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.2s;
}

.close-btn:hover {
  background: #f8f9fa;
  color: #e74c3c;
}

.form-body {
  padding: 25px;
}

.form-group {
  margin-bottom: 25px;
}

.form-group label {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 600;
  color: #2c3e50;
  margin-bottom: 10px;
  font-size: 1rem;
}

.label-icon {
  font-size: 1.2rem;
}

.form-input,
.form-textarea {
  width: 100%;
  padding: 14px 16px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  font-size: 1rem;
  transition: all 0.3s;
  font-family: inherit;
}

.form-input:focus,
.form-textarea:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.form-input.error {
  border-color: #e74c3c;
}

.error-message {
  color: #e74c3c;
  font-size: 0.85rem;
  margin-top: 5px;
}

.input-hint {
  color: #7f8c8d;
  font-size: 0.85rem;
  margin-top: 5px;
}

/* Выбор типа */
.type-selector {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
  gap: 10px;
  margin-top: 10px;
}

.type-option {
  padding: 15px;
  border: 2px solid #e0e0e0;
  border-radius: 10px;
  cursor: pointer;
  text-align: center;
  transition: all 0.3s;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.type-option:hover {
  border-color: #667eea;
  background: #f8f9ff;
}

.type-option.selected {
  border-color: #667eea;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.type-icon {
  font-size: 1.8rem;
}

.type-label {
  font-size: 0.9rem;
  font-weight: 600;
}

/* Кнопки формы */
.form-actions {
  display: flex;
  gap: 15px;
  margin-top: 30px;
  padding-top: 20px;
  border-top: 1px solid #eee;
}

.btn {
  flex: 1;
  padding: 14px 20px;
  border: none;
  border-radius: 10px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

.btn-primary {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.btn-primary:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

.btn-secondary {
  background: #f8f9fa;
  color: #7f8c8d;
  border: 2px solid #e0e0e0;
}

.btn-secondary:hover {
  background: #e9ecef;
  color: #495057;
}

.spinner {
  width: 20px;
  height: 20px;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: white;
  animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* Сетка ресурсов */
.resources-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 25px;
  margin-top: 20px;
}

.resource-card {
  background: white;
  border-radius: 15px;
  overflow: hidden;
  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;
  border: 1px solid #f0f0f0;
}

.resource-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

/* Цвета по типам */
.type-room { border-top: 4px solid #3498db; }
.type-equipment { border-top: 4px solid #2ecc71; }
.type-service { border-top: 4px solid #9b59b6; }
.type-vehicle { border-top: 4px solid #e67e22; }
.type-other { border-top: 4px solid #95a5a6; }

.resource-card-header {
  padding: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #f8f9fa;
  border-bottom: 1px solid #eee;
}

.resource-type-badge {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: white;
  border-radius: 20px;
  font-size: 0.9rem;
  font-weight: 600;
}

.type-icon {
  font-size: 1.2rem;
}

.resource-actions {
  display: flex;
  gap: 8px;
}

.action-btn {
  padding: 8px 12px;
  border: none;
  border-radius: 8px;
  font-size: 0.9rem;
  cursor: pointer;
  transition: all 0.2s;
  display: flex;
  align-items: center;
  gap: 5px;
}

.edit-btn {
  background: #e3f2fd;
  color: #1976d2;
}

.edit-btn:hover {
  background: #bbdefb;
}

.delete-btn {
  background: #ffebee;
  color: #d32f2f;
}

.delete-btn:hover {
  background: #ffcdd2;
}

.action-text {
  display: none;
}

@media (min-width: 768px) {
  .action-text {
    display: inline;
  }
}

.resource-card-body {
  padding: 25px;
}

.resource-name {
  margin: 0 0 15px 0;
  color: #2c3e50;
  font-size: 1.3rem;
  font-weight: 700;
}

.resource-description {
  color: #7f8c8d;
  line-height: 1.5;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #f0f0f0;
}

.resource-info {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.info-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.info-icon {
  font-size: 1.2rem;
  width: 30px;
  text-align: center;
}

.info-content {
  flex: 1;
}

.info-label {
  display: block;
  font-size: 0.85rem;
  color: #7f8c8d;
  margin-bottom: 3px;
}

.info-value {
  font-weight: 600;
  color: #2c3e50;
}

.status-badge {
  display: inline-block;
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 0.8rem;
  font-weight: 600;
}

.available {
  background: #d4edda;
  color: #155724;
}

.resource-card-footer {
  padding: 20px;
  border-top: 1px solid #f0f0f0;
  text-align: center;
}

.btn-sm {
  padding: 10px 20px;
  font-size: 0.9rem;
}

.btn-outline {
  background: transparent;
  border: 2px solid #667eea;
  color: #667eea;
}

.btn-outline:hover {
  background: #667eea;
  color: white;
}

/* Пустое состояние */
.empty-state {
  text-align: center;
  padding: 60px 20px;
  background: white;
  border-radius: 15px;
  box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
  margin-top: 30px;
}

.empty-state-icon {
  font-size: 4rem;
  margin-bottom: 20px;
  opacity: 0.5;
}

.empty-state h3 {
  color: #2c3e50;
  margin-bottom: 10px;
}

.empty-state p {
  color: #7f8c8d;
  max-width: 400px;
  margin: 0 auto 25px;
}

/* Адаптивность */
@media (max-width: 768px) {
  .page-title {
    font-size: 2rem;
  }
  
  .resources-grid {
    grid-template-columns: 1fr;
  }
  
  .modal-content {
    width: 95%;
  }
  
  .form-actions {
    flex-direction: column;
  }
}

@media (max-width: 480px) {
  .resource-list-container {
    padding: 15px;
  }
  
  .page-title {
    font-size: 1.7rem;
  }
  
  .add-resource-btn {
    padding: 15px 20px;
    font-size: 1.1rem;
  }
  
  .btn-icon {
    font-size: 2rem;
  }
}
</style>