<template>
  <div class="notification-bell">
    <button @click="toggleNotifications" class="notification-button">
      🔔 
      <span v-if="unreadCount > 0" class="notification-badge">
        {{ unreadCount }}
      </span>
    </button>
    
    <div v-if="showNotifications" class="notification-list">
      <div v-if="notifications.length === 0" class="notification-empty">
        Нет новых уведомлений
      </div>
      
      <div 
        v-for="notification in notifications" 
        :key="notification.id"
        class="notification-item"
        :class="{ 'unread': !notification.read }"
        @click="markAsRead(notification.id)"
      >
        <div class="notification-message">{{ notification.message }}</div>
        <div class="notification-time">{{ formatTime(notification.time) }}</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'NotificationBellComponent',
  data() {
    return {
      showNotifications: false,
      notifications: [
        { 
          id: 1, 
          message: 'Ваше бронирование Конференц-зала A подтверждено', 
          time: new Date(Date.now() - 3600000), 
          read: false 
        },
        { 
          id: 2, 
          message: 'Напоминание: завтра в 10:00 фотосессия', 
          time: new Date(Date.now() - 7200000), 
          read: true 
        }
      ]
    };
  },
  computed: {
    unreadCount() {
      return this.notifications.filter(n => !n.read).length;
    }
  },
  methods: {
    toggleNotifications() {
      this.showNotifications = !this.showNotifications;
    },
    formatTime(date) {
      const now = new Date();
      const diffMs = now - date;
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);
      
      if (diffMins < 60) {
        return `${diffMins} мин. назад`;
      } else if (diffHours < 24) {
        return `${diffHours} ч. назад`;
      } else if (diffDays < 7) {
        return `${diffDays} дн. назад`;
      } else {
        return date.toLocaleDateString();
      }
    },
    markAsRead(id) {
      const notification = this.notifications.find(n => n.id === id);
      if (notification) {
        notification.read = true;
      }
    },
    // Упрощенная версия без WebSocket
    connectToNotifications() {
      // Используйте polling вместо WebSocket для простоты
      // или укажите правильный URL вашего сервера
      if (process.env.NODE_ENV === 'development') {
        console.log('WebSocket отключен в режиме разработки');
        return;
      }
      
      // Только если бэкенд доступен
      const wsUrl = process.env.VUE_APP_WS_URL || 'ws://localhost:3000/notifications';
      try {
        const ws = new WebSocket(wsUrl);
        ws.onmessage = (event) => {
          const notification = JSON.parse(event.data);
          this.notifications.unshift(notification);
        };
      } catch (error) {
        console.warn('WebSocket не доступен:', error);
      }
    }
  },
  mounted() {
    // Отложенный вызов или используйте polling
    // this.connectToNotifications();
    
    // Или используйте polling каждые 30 секунд
    setInterval(() => {
      // Здесь можно сделать запрос к API для получения уведомлений
      // fetch('/api/notifications').then(...)
    }, 30000);
  }
};
</script>

<style scoped>
.notification-bell {
  position: relative;
}

.notification-button {
  position: relative;
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  padding: 5px;
}

.notification-badge {
  position: absolute;
  top: -5px;
  right: -5px;
  background: #f44336;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.notification-list {
  position: absolute;
  top: 100%;
  right: 0;
  background: white;
  border: 1px solid #ddd;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  width: 300px;
  max-height: 400px;
  overflow-y: auto;
  z-index: 1000;
}

.notification-empty {
  padding: 20px;
  text-align: center;
  color: #666;
}

.notification-item {
  padding: 12px 16px;
  border-bottom: 1px solid #050505ff;
  cursor: pointer;
}

.notification-item.unread {
  background: #f0f7ff;
}

.notification-item:hover {
  background: #f5f5f5;
}

.notification-message {
  font-size: 14px;
  margin-bottom: 4px;
  color: #000000ff;
}

.notification-time {
  font-size: 12px;
  color: #666;
}
</style>