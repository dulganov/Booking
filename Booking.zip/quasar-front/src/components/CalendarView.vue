<template>
  <div class="calendar">
    <div class="calendar-header">
      <button @click="prevWeek">←</button>
      <h2>{{ currentWeekRange }}</h2>
      <button @click="nextWeek">→</button>
    </div>
    
    <div class="calendar-grid">
      <div class="time-slots">
        <div v-for="hour in hours" :key="hour" class="time-slot">
          {{ hour }}:00
        </div>
      </div>
      
      <div class="resource-columns">
        <div 
          v-for="resource in resources" 
          :key="resource.id"
          class="resource-column"
        >
          <div class="resource-header">{{ resource.name }}</div>
          <div 
            v-for="hour in hours" 
            :key="hour"
            class="time-cell"
            @click="openBookingForm(resource, hour)"
            :class="{ 
              'booked': isBooked(resource.id, hour),
              'available': !isBooked(resource.id, hour)
            }"
          >
            {{ getBookingInfo(resource.id, hour) }}
          </div>
        </div>
      </div>
    </div>
    
    <BookingFormComponent 
      v-if="showBookingForm"
      :resource="selectedResource"
      :startTime="selectedTime"
      @book="handleBooking"
      @cancel="closeBookingForm"
    />
  </div>
</template>

<script>
import BookingFormComponent from './BookingForm.vue';

export default {
  name: 'CalendarViewComponent',
  components: {
    BookingFormComponent
  },
  data() {
    return {
      currentDate: new Date(),
      showBookingForm: false,
      selectedResource: null,
      selectedTime: null,
      hours: [9, 10, 11, 12, 13, 14, 15, 16, 17],
      resources: [
        { id: 1, name: 'Конференц-зал A' },
        { id: 2, name: 'Фотостудия' },
        { id: 3, name: 'Проектор' }
      ],
      bookings: [
        { id: 1, resourceId: 1, startTime: new Date(new Date().setHours(10, 0, 0, 0)), purpose: 'Совещание' },
        { id: 2, resourceId: 2, startTime: new Date(new Date().setHours(14, 0, 0, 0)), purpose: 'Фотосессия' }
      ]
    };
  },
  computed: {
    currentWeekRange() {
      const startOfWeek = new Date(this.currentDate);
      startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay() + 1);
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(endOfWeek.getDate() + 6);
      
      return `${startOfWeek.toLocaleDateString()} - ${endOfWeek.toLocaleDateString()}`;
    }
  },
  methods: {
    prevWeek() {
      const newDate = new Date(this.currentDate);
      newDate.setDate(newDate.getDate() - 7);
      this.currentDate = newDate;
    },
    nextWeek() {
      const newDate = new Date(this.currentDate);
      newDate.setDate(newDate.getDate() + 7);
      this.currentDate = newDate;
    },
    isBooked(resourceId, hour) {
      const targetTime = new Date(this.currentDate);
      targetTime.setHours(hour, 0, 0, 0);
      
      return this.bookings.some(booking => 
        booking.resourceId === resourceId && 
        booking.startTime.getHours() === hour &&
        booking.startTime.toDateString() === targetTime.toDateString()
      );
    },
    getBookingInfo(resourceId, hour) {
      const booking = this.bookings.find(b => 
        b.resourceId === resourceId && 
        b.startTime.getHours() === hour &&
        b.startTime.toDateString() === new Date(this.currentDate).toDateString()
      );
      return booking ? 'Занято' : 'Свободно';
    },
    openBookingForm(resource, hour) {
      if (!this.isBooked(resource.id, hour)) {
        this.selectedResource = resource;
        const selectedTime = new Date(this.currentDate);
        selectedTime.setHours(hour, 0, 0, 0);
        this.selectedTime = selectedTime;
        this.showBookingForm = true;
      }
    },
    closeBookingForm() {
      this.showBookingForm = false;
      this.selectedResource = null;
      this.selectedTime = null;
    },
    async handleBooking(bookingData) {
      // Проверка на конфликт
      const conflict = this.bookings.some(b => 
        b.resourceId === bookingData.resourceId &&
        Math.abs(b.startTime - bookingData.startTime) < 3600000 &&
        b.startTime.toDateString() === bookingData.startTime.toDateString()
      );
      
      if (conflict) {
        alert('Это время уже занято!');
        return;
      }
      
      // Добавляем в локальный массив
      const newBooking = {
        id: this.bookings.length + 1,
        ...bookingData
      };
      this.bookings.push(newBooking);
      
      // Отправка на сервер
      try {
        const response = await fetch('/api/bookings', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(bookingData)
        });
        
        if (!response.ok) {
          throw new Error('Ошибка сервера');
        }
        
        this.$emit('notification', {
          type: 'success',
          message: 'Бронирование создано!'
        });
      } catch (error) {
        console.error('Ошибка бронирования:', error);
        // Откатываем локальное изменение при ошибке
        this.bookings = this.bookings.filter(b => b.id !== newBooking.id);
        alert('Не удалось создать бронирование. Попробуйте снова.');
      }
      
      this.closeBookingForm();
    }
  }
};
</script>

<style scoped>
.calendar {
  padding: 20px;
}

.calendar-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
}

.calendar-header button {
  padding: 8px 16px;
  background: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.calendar-grid {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 1px;
  background: #ddd;
  border: 1px solid #ddd;
}

.time-slots {
  background: white;
}

.time-slot {
  height: 60px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid #eee;
  padding: 0 10px;
  font-weight: bold;
}

.resource-columns {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  background: white;
}

.resource-header {
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f5f5;
  font-weight: bold;
  border-bottom: 1px solid #ddd;
}

.time-cell {
  height: 60px;
  border: 1px solid #eee;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
}

.time-cell.available {
  background: #e8f5e9;
  cursor: pointer;
}

.time-cell.available:hover {
  background: #c8e6c9;
}

.time-cell.booked {
  background: #ffebee;
  cursor: not-allowed;
  color: #c62828;
}
</style>